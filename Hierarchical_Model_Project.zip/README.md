# Hierarchical Model for Multi-Label Classification

This project implements a hierarchical model for multi-label classification of emails into Type2, Type3, and Type4 categories.

## Project Structure

```
CA_Code_original/
│
├── Config.py
├── embeddings.py
├── main.py
├── out.csv
├── preprocess.py
├── data/
│   ├── AppGallery.csv
│   └── Purchasing.csv
├── model/
│   ├── __init__.py
│   ├── base.py
│   ├── randomforest.py
├── modelling/
│   ├── data_model.py
│   ├── modelling.py
├── hierarchical_model/
│   ├── preprocess_hierarchical.py
│   ├── model_hierarchical.py
│   ├── main_hierarchical.py
│   ├── requirements.txt
└── README.md
```

## Setup

1. Clone the repository:
    ```bash
    git clone <repository-url>
    cd CA_Code_original/hierarchical_model
    ```

2. Install the dependencies:
    ```bash
    pip install -r requirements.txt
    ```

3. Run the main script:
    ```bash
    python main_hierarchical.py
    ```

## Description

- `preprocess_hierarchical.py`: Contains functions to load and preprocess the data.
- `model_hierarchical.py`: Contains functions to train and predict using different models.
- `main_hierarchical.py`: The main script to run the hierarchical classification process.
